package com.NLP.service;

public interface ExportService {
    String exportDataset(Long datasetId);
}