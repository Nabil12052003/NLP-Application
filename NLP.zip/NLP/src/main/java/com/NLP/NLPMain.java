package com.NLP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NLPMain {

    public static void main(String[] args) {
        SpringApplication.run(NLPMain.class, args);
    }

}
