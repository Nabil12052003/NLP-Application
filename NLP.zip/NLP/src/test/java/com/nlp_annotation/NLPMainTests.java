package com.nlp_annotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NLPMainTests {

    @Test
    void contextLoads() {
    }

}
